package ca.mcgill.ecse321.sportcenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportcenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
